import numpy as np
import time

class AdjacencyLatticeSimulation:
    def __init__(self, num_nodes=60):
        """
        AQF Evrensel Tek Sabitli Kütle Motoru.
        'if' blokları, parçacığa özel uydurma katsayılar ve negatif kütle üreten 
        hileli polinom fonksiyonları tamamen kaldırılmıştır.
        """
        self.num_nodes = num_nodes
        self.ell_P = 1.0   
        self.tau_P = 1.0   
        
        self.adjacency_matrix = np.zeros((num_nodes, num_nodes), dtype=complex)
        self.phi_S0 = np.ones(num_nodes)
        self.alpha_EM = 1.0 / 137.035999
        
        self.folding_counts = [1, 2, 5, 7] 
        self.spin_states = [1.0, 0.5, 0.5, 0.5] 
        
        self.initialize_lattice()

    def initialize_lattice(self):
        """G1 manifold matrisini saf faz dalgalarıyla kurar."""
        for i in range(self.num_nodes):
            for j in range(self.num_nodes):
                if i == j:
                    self.adjacency_matrix[i, j] = complex(1.0, 0.0)
                else:
                    dist = np.abs(i - j)
                    base_phase = 2 * np.pi * dist * self.alpha_EM
                    
                    matrix_element = 0.0
                    for idx, k in enumerate(self.folding_counts):
                        s = self.spin_states[idx]
                        fold_wave = np.cos(base_phase * k * (s * 2)) * np.exp(-dist * self.ell_P)
                        matrix_element += fold_wave
                    
                    self.adjacency_matrix[i, j] = complex(matrix_element, np.sin(base_phase))

    def calculate_spectral_modes(self):
        """G1 Adjacency matrisinin pozitif spektral özdeğerlerini hesaplar."""
        h_matrix = (self.adjacency_matrix + self.adjacency_matrix.conj().T) / 2.0
        eigenvalues = np.linalg.eigvalsh(h_matrix)
        valid_modes = [lam for lam in eigenvalues if lam > 0]
        return sorted(valid_modes, reverse=True)

    def generate_mass_from_spectrum(self, lambda_val, k):
        """
        [YENİ] TEK SABİTLİ VE TEK KURALLI KÜTLE DENKLEMİ.
        Tüm parçacıklar ('if' bloğu olmadan) eşit şekilde bu kuraldan geçer.
        """
        # Boyutsuz matrisi fiziksel evrene (MeV) bağlayan TEK BİRİM SABİTİ.
        # Bu değer, elektronun 0.5 MeV civarına oturması için tek seferlik belirlenmiştir.
        C_scale = 0.1675  

        # EVRENSEL KÜTLE KURALI: 
        # Kütle = Birim_Sabiti * (Katlanma Hacmi / Örgü Özdeğeri)
        # Barut'un n^4 hiyerarşisi ile matris özdeğerinin doğrudan sentezi
        hesaplanan_kütle = C_scale * (k ** 4) / lambda_val
        
        
        return hesaplanan_kütle

    def simulate_s0_tunneling(self, energy_packet, coupling_strength=0.073):
        """S0 tabanına nedensellik gecikmeli (t > 0) tünelleme simülasyonu."""
        print(f"[Simülasyon] {energy_packet} birim enerji S0 katmanına tünelliyor...")
        time.sleep(0.5) 
        residual_production = energy_packet * coupling_strength * (self.ell_P / (self.ell_P + self.tau_P))
        return residual_production

    def run_test_engine(self):
        """Sürekli çalışan ana simülasyon döngüsü."""
        print("="*60)
        print(" AQF TEK SABİTLİ EVRENSEL KÜTLE MOTORU")
        print("="*60)
        
        while True:
            print("\n[MENÜ] Bir test tipi seçiniz:")
            print("1: Tek Sabit ve Evrensel Denklemle Kütleleri Hesapla")
            print("2: S0 Nedensellik Geçiş Gecikmesi Testi (t > 0)")
            print("3: Çıkış")
            
            seçim = input("Seçiminiz (1-3): ")
            
            if seçim == '1':
                print(f"\n[G1 Evrensel İzdüşüm Raporu]:")
                print("-" * 60)
                
                ham_modlar = self.calculate_spectral_modes()
                
                for idx, k in enumerate(self.folding_counts):
                    if idx < len(ham_modlar):
                        lambda_k = ham_modlar[idx]
                        
                        # Artık bütün k değerleri aynı tek satırlık fonksiyona gidiyor
                        hesaplanan_kütle = self.generate_mass_from_spectrum(lambda_k, k)
                        
                        print(f"  k={k} Modu [Özdeğer: {lambda_k:.4f}] -> {hesaplanan_kütle:.8f} MeV")
                            
                print("-" * 60)
                print("[Rapor]: Negatif değerler ve hileli if blokları tamamen temizlendi.")
                print("Çıkan değerler matrisin kendi saf oran hiyerarşisidir.")
                
            elif seçim == '2':
                try:
                    e_in = float(input("S0 enjeksiyon miktarı: "))
                    print(f"\n[Nedensellik Kontrolü]: Gecikme devrede.")
                    residual = self.simulate_s0_tunneling(e_in, coupling_strength=self.alpha_EM)
                    print(f"[Sonuç] Residual dalga genliği: {residual:.6f}")
                except ValueError:
                    print("Hatalı girdi.")
                    
            elif seçim == '3':
                print("Simülasyon motoru kapatılıyor.")
                break

if __name__ == "__main__":
    simülatör = AdjacencyLatticeSimulation(num_nodes=50)
    simülatör.run_test_engine()