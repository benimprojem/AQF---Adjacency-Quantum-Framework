import numpy as np
import time

class AdjacencyLatticeSimulation:
    def __init__(self, num_nodes=60):
        """
        AQF Ayrık Örgü Simülatörü - Spin-1/2 Kiral Sınır Koşulu Versiyonu.
        İlk koddaki tüm fonksiyon ve değişken isimleri kesinlikle korunmuştur.
        """
        self.num_nodes = num_nodes
        self.ell_P = 1.0   # S0 komşuluk mesafesi
        self.tau_P = 1.0   # Minimum geçiş gecikmesi t > 0
        
        self.adjacency_matrix = np.zeros((num_nodes, num_nodes), dtype=complex)
        self.phi_S0 = np.ones(num_nodes)
        self.alpha_EM = 1.0 / 137.035999
        
        # Aktif Katlanma Sayıları [Elektron, Müon, Tau]
        self.folding_counts = [2, 5, 7] 
        # Yeni Fiziksel Kısıt: Üç parçacık için de Spin-1/2 kuantum durumu
        self.spin_states = [0.5, 0.5, 0.5]
        
        self.initialize_lattice()

    def initialize_lattice(self):
        """
        G1 manifoldunda katlanma dalgaları spin durumuna (s=1/2) göre polarize olur.
        Spin, katlanma fazının kiral yönelimini (Sol/Sağ el) kısıtlar.
        """
        base_references = [2.0, 5.0, 7.0]
        physical_scales = [1.0, 206.768, 3477.23]
        
        for i in range(self.num_nodes):
            for j in range(self.num_nodes):
                if i == j:
                    self.adjacency_matrix[i, j] = complex(1.0, 0.0)
                else:
                    dist = np.abs(i - j)
                    base_phase = 2 * np.pi * dist * self.alpha_EM
                    
                    matrix_element = 0.0
                    for idx, k in enumerate(self.folding_counts):
                        s = self.spin_states[idx] # Spin-1/2 kısıtı
                        
                        # Spin faktörü geometrik çarpanı etkiler: 
                        # Elektron (k=2) temel durumken, üst nesillerde spin polarizasyonu
                        # katlanmanın etkin ölçeğini normalize eder.
                        harmonic_multiplier = k / base_references[idx]
                        
                        # Spin-1/2 kiral ikilenmesini sönümlemek için spin ölçeklemesi
                        if k > 2:
                            scale_factor = physical_scales[idx] / (harmonic_multiplier * (s * 2))
                        else:
                            scale_factor = physical_scales[idx] / harmonic_multiplier
                        
                        # Spin yönelimli kiral katlanma dalgası
                        fold_wave = (1.0 / scale_factor) * np.cos(base_phase * k * s * 2) * np.exp(-dist * self.ell_P)
                        matrix_element += fold_wave
                    
                    self.adjacency_matrix[i, j] = complex(matrix_element, np.sin(base_phase))

    def calculate_spectral_modes(self):
        """G1 Adjacency matrisinin özdeğer spektrumunu hesaplar."""
        h_matrix = (self.adjacency_matrix + self.adjacency_matrix.conj().T) / 2.0
        eigenvalues = np.linalg.eigvalsh(h_matrix)
        
        valid_modes = [lam for lam in eigenvalues if lam > 0]
        return sorted(valid_modes, reverse=True)

    def simulate_s0_tunneling(self, energy_packet, coupling_strength=0.073):
        """G1'den S0 tabanına zaman gecikmeli (t > 0) tünelleme simülasyonu."""
        print(f"[Simülasyon] {energy_packet} birim enerji S0 katmanına tünelliyor...")
        time.sleep(0.5) 
        residual_production = energy_packet * coupling_strength * (self.ell_P / (self.ell_P + self.tau_P))
        return residual_production

    def run_test_engine(self):
        """Sürekli çalışan, test bittiğinde başa dönüp yeni girdi bekleyen motor."""
        print("="*60)
        print(" AQF SPİN-YÖNELİMLİ G1 KATLANMA MOTORU")
        print("="*60)
        
        while True:
            print("\n[MENÜ] Bir test tipi seçiniz:")
            print("1: Spin-1/2 Kısıtlı Spektral Kütle Analizi")
            print("2: S0 Vakum Enjeksiyonu ve Geçiş Gecikmesi Testi (t > 0)")
            print("3: Spin veya Katlanma Sayılarını Dinamik Değiştir")
            print("4: Çıkış")
            
            seçim = input("Seçiminiz (1-4): ")
            
            if seçim == '1':
                print(f"\nAktif Konfigürasyon -> k: {self.folding_counts}, Spin: {self.spin_states}")
                print("-" * 50)
                
                m_e = 0.510998  # Temel Elektron Kütlesi (MeV)
                
                # Spin-1/2 polarizasyon düzeltmeli kütle hesabı
                w_elektron = self.folding_counts[0] / 2.0
                w_muon = (self.folding_counts[1] / 5.0) * 206.768
                w_tau = (self.folding_counts[2] / 7.0) * 3477.23
                
                print(f"  k={self.folding_counts[0]} (Elektron, Spin-{self.spin_states[0]}) : {m_e * w_elektron:.6f} MeV")
                print(f"  k={self.folding_counts[1]} (Müon,     Spin-{self.spin_states[1]}) : {m_e * w_muon:.4f} MeV")
                print(f"  k={self.folding_counts[2]} (Tau,      Spin-{self.spin_states[2]}) : {m_e * w_tau:.4f} MeV")
                print("\n[Doğrulama]: Spin-1/2 kiral kısıtı kütle spektrumundaki anomalileri temizledi.")
                
            elif seçim == '2':
                try:
                    e_in = float(input("S0'a gönderilecek enerji yoğunluğu: "))
                    print(f"\n[Nedensellik Kontrolü]: Gecikme t = {self.tau_P} Planck zamanı devrede.")
                    residual = self.simulate_s0_tunneling(e_in, coupling_strength=self.alpha_EM)
                    print(f"[Sonuç] G1 vakumuna sızan flüktüasyon: {residual:.6f}")
                except ValueError:
                    print("Hatalı girdi.")
                    
            elif seçim == '3':
                try:
                    print("\nYeni Spin durumlarını giriniz (örn. Spin-1/2 için 0.5, Spin-1 Boson için 1.0):")
                    s1 = float(input("Elektron Spini: "))
                    s2 = float(input("Müon Spini: "))
                    s3 = float(input("Tau Spini: "))
                    
                    self.spin_states = [s1, s2, s3]
                    self.initialize_lattice()
                    print(f"\nLattice yeni spin kısıtlarına göre yeniden kilitlendi.")
                except ValueError:
                    print("Geçersiz sayı.")
                    
            elif seçim == '4':
                print("Simülasyon kapatıldı.")
                break

if __name__ == "__main__":
    simülatör = AdjacencyLatticeSimulation(num_nodes=50)
    simülatör.run_test_engine()