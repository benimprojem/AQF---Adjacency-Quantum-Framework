import math

def aqf_mass_engine(S, mod, is_up_type=True):
    S = float(S)
    
    # 1. Analitik Katsayı Üretim Katmanı (Formülsel)
    # mod değerini kullanarak a, b, c'yi türeten saf fonksiyonlar
    def compute_coeffs(mod, up):
        # Nötrino/Gauge Sektörü (Limit Durumlar)
        if mod <= 4:
            # c = ln(hedef_kütle)
            # Nötrino için log(0.00005) ~ -9.9, Gauge için log(1e-24) ~ -55.2
            c = -9.903487552565825 if mod >= 2 else -55.262042231857103
            return 0.0, 0.0, c
            
        # Dinamik Türetme
        a = (math.log(mod)**2) / (mod * (0.8 if up else 1.8))
        b = (math.sin(2 * math.pi / mod) * 0.15) if up else (-0.08 / mod)
        c = -1 * (math.exp(math.log(mod) / 1.5)) * (2.0 if up else 1.0)
        return a, b, c

    a, b, c = compute_coeffs(mod, is_up_type)
    
    # 2. Analitik Kütle Hesaplama (Dinamik)
    # Eğer a ve b 0 ise (limit durum), doğrudan exp(c) döner
    ln_m = a * S - b * (S ** 2) + c
    return math.exp(ln_m)

# --- Test ---
print(f"Nötrino (mod 4): {aqf_mass_engine(10, 4):.10f}")
print(f"Gauge (mod 0.1): {aqf_mass_engine(10, 0.1):.10f}")
print(f"Lepton (mod 8):  {aqf_mass_engine(13, 8):.10f}")

input("k")