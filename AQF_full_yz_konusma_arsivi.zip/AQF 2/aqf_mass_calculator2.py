import math

def aqf_mass_calculator(S, modular_filter="mod8"):
    """
    AQF Spektral Kütle Üretim Fonksiyonu.
    S=0 durumunda gauge sektörü için S0 kalıntı sızıntısını (Proca limitini) hesaplar.
    Denklem: ln(m) = a*S - b*S^2 + c
    """
    S = float(S)
    
    if modular_filter == "mod8":
        # Lepton Merdiveni
        a, b, c = 1.333272838, 0.01961067789, -14.68972795
        ln_m = a * S - b * (S ** 2) + c
        return math.exp(ln_m)
        
    elif modular_filter == "mod6":
        # Kuark Monoton Merdiveni
        if round(S) % 6 == 0:
            a, b, c = 0.651420, 0.005051375, -2.9382135
        else:
            a, b, c = 0.26336855, -0.010803816, -1.2508306
            
        ln_m = a * S - b * (S ** 2) + c
        return math.exp(ln_m)
        
    elif modular_filter in ["mod2", "mod4"]:
        # Nötrino Sektörü (Kütleli Prototip)
        a, b, c = 0.0, 0.0, -9.90348755
        ln_m = a * S - b * (S ** 2) + c
        return math.exp(ln_m)
        
    elif modular_filter == "gauge":
        # DÜZENLEME: Sert sıfır yerine S0 kalıntı spektral yoğunluk limiti (c_gauge)
        # S = 0 için ln(m) = c olur. c = -55.25850943 => m = 1.0e-24 MeV (PDG Foton Üst Sınırı)
        a, b, c = 0.0, 0.0, -55.25850943
        ln_m = a * S - b * (S ** 2) + c
        return math.exp(ln_m)
    else:
        raise ValueError(f"Geçersiz modüler filtre: {modular_filter}")

def run_continuous_aqf_test():
    """
    Sürekli çalışan, çok küçük kütle limitlerini hassas formatta basan test motoru.
    """
    MASTER_PARTICLE_DB = {
        "mod8": {
            "Başlık": "LEPTON SEKTÖRÜ (mod8)",
            "Parçacıklar": {
                "Electron": {"target": 0.511, "S": 13},
                "Muon":     {"target": 105.658, "S": 21},
                "Tau":      {"target": 1776.860, "S": 29}
            }
        },
        "mod6": {
            "Başlık": "KUARK SEKTÖRÜ (mod6) - MONOTON HİYERARŞİ",
            "Parçacıklar": {
                "Up Quark":      {"target": 2.200, "S": 6},
                "Down Quark":    {"target": 4.700, "S": 8},
                "Strange Quark": {"target": 95.000, "S": 14},
                "Charm Quark":   {"target": 1275.000, "S": 18},
                "Bottom Quark":  {"target": 4180.000, "S": 20},
                "Top Quark":     {"target": 172500.000, "S": 30}
            }
        },
        "mod2": {
            "Başlık": "NÖTRİNO SEKTÖRÜ (mod2)",
            "Parçacıklar": {"Neutrino v1": {"target": 5.0e-5, "S": 2}}
        },
        "mod4": {
            "Başlık": "NÖTRİNO SEKTÖRÜ (mod4)",
            "Parçacıklar": {"Neutrino v2": {"target": 5.0e-5, "S": 4}}
        },
        "gauge": {
            "Başlık": "AYAR BOZONLARI SEKTÖRÜ (gauge) - PROCA KÜTLE LİMİTİ",
            "Parçacıklar": {
                "Photon": {"target": 1.0e-24, "S": 0}, # Deneysel PDG Üst Sınırı (MeV)
                "Gluon":  {"target": 0.000, "S": 0}    # Teorik Sıfır
            }
        }
    }

    print("=======================================================================")
    print("      AQF EVRENSEL MUTLAK KÜTLE DOĞRULAMA VE LABORATUVAR SİSTEMİ       ")
    print("=======================================================================")
    
    while True:
        print("\n[DURUM: BEKLEMEDE] Lütfen test etmek istediğiniz sektörü seçin:")
        print("1 - Lepton Spektrumu (mod8)")
        print("2 - Kuark Spektrumu  (mod6)")
        print("3 - Nötrino Spektrumu (mod2/mod4)")
        print("4 - Ayar Bozonları / Foton Proca Limiti (gauge)")
        print("5 - Tüm Sektörleri Eşzamanlı Doğrula")
        print("6 - Sistemi Kapat")
        
        secim = input("Seçiminiz (1-6): ").strip()
        
        if secim == "6":
            print("\n[SİSTEM] Laboratuvar kapatılıyor.")
            break
            
        selected_mods = []
        if secim == "1": selected_mods = ["mod8"]
        elif secim == "2": selected_mods = ["mod6"]
        elif secim == "3": selected_mods = ["mod2", "mod4"]
        elif secim == "4": selected_mods = ["gauge"]
        elif secim == "5": selected_mods = ["mod8", "mod6", "mod2", "mod4", "gauge"]
        else:
            print("[UYARI] Geçersiz seçim!")
            continue

        for m_filter in selected_mods:
            sector_data = MASTER_PARTICLE_DB[m_filter]
            print(f"\n================ {sector_data['Başlık']} ================")
            print(f"{'Parçacık Adı':<15} | {'Hedef Kütle':<18} | {'Atanan S':<10} | {'Model Kütlesi':<20} | {'Mutlak Sapma':<18}")
            print("-" * 90)
            
            sorted_particles = sorted(sector_data["Parçacıklar"].items(), key=lambda x: x[1]["S"])
            
            for p_name, data in sorted_particles:
                S_val = data["S"]
                target_mass = data["target"]
                
                model_mass = aqf_mass_calculator(S_val, modular_filter=m_filter)
                abs_deviation = abs(model_mass - target_mass)
                
                # Çok küçük sayılar için bilimsel gösterim formatı aktiftir
                fmt_target = f"{target_mass:.3e}" if target_mass < 0.001 and target_mass > 0 else f"{target_mass:.3f}"
                fmt_model = f"{model_mass:.3e}" if model_mass < 0.001 else f"{model_mass:.3f}"
                fmt_dev = f"{abs_deviation:.3e}" if abs_deviation < 0.001 and abs_deviation > 0 else f"{abs_deviation:.3f}"
                
                print(f"{p_name:<15} | {fmt_target:<18} | S={S_val:<8} | {fmt_model:<20} | {fmt_dev:<18}")
            print("=======================================================================")

if __name__ == "__main__":
    run_continuous_aqf_test()