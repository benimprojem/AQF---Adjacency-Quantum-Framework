import math

class AQFTestFramework:
    def __init__(self):
        self.M_P = 1.2209e19
        self.ALPHA = 1.9767
        self.KAPPA = 0.09668
        # Sektörel olarak kilitlenmiş vakum tabanları
        self.C_MOD = {8: -99.407475, 6: -98.761236}
        
    def calculate_mass(self, S, mod):
        geom_factor = math.log(mod) * math.sin((2 * math.pi) / mod)
        a = self.ALPHA * math.log(mod)
        b = 0.5 * (self.KAPPA / geom_factor)
        
        c = self.C_MOD.get(mod)
        log_m = (a * S) - (b * S**2) + c
        return math.exp(log_m) * self.M_P

# Test
engine = AQFTestFramework()
tests = [("Elektron", 13, 8, 0.000511), ("Up Kuark", 16, 6, 0.002200)]

print(f"{'PARÇACIK':<15} | {'HESAPLANAN':<15} | {'HEDEF':<15} | {'SAPMA'}")
for name, S, mod, target in tests:
    val = engine.calculate_mass(S, mod)
    print(f"{name:<15} | {val:.6f} | {target:.6f} | %{abs(val-target)/target*100:.4f}")

input("k")