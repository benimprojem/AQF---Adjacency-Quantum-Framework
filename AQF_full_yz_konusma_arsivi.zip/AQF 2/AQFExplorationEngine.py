import numpy as np
import scipy.sparse as sparse
from scipy.sparse.linalg import eigs

class AQFSequentialScanner:
    def __init__(self):
        print("[AQF SYSTEM] Düz Ardışık Tarama Motoru Başlatıldı.")
        print("[AQF SYSTEM] Rezonans dışı dinamik kırılma noktaları aranıyor...\n")

    def build_transport_operator(self, shell_size, modular_class, phase_mismatch=0.01):
        row, col, data = [], [], []
        for i in range(shell_size):
            for offset in [-2, -1, 1, 2]:
                j = (i + offset) % shell_size
                if i == j and shell_size > 1: 
                    continue
                
                # Orijinal faz formülü
                phi_ij = offset * (2 * np.pi / modular_class) + phase_mismatch
                
                row.append(i)
                col.append(j)
                data.append(np.exp(1j * phi_ij))
                
        T_ij = sparse.coo_matrix((data, (row, col)), shape=(shell_size, shell_size)).tocsr()
        return T_ij

    def execute_single_test(self, shell_size, modular_class):
        if shell_size < 3: 
            return None
        
        T_ij = self.build_transport_operator(shell_size, modular_class)
        
        try:
            if shell_size <= 6:
                eigenvalues = np.linalg.eigvals(T_ij.toarray())
            else:
                eigenvalues, _ = eigs(T_ij, k=min(3, shell_size-2), which='LM', maxiter=1000)
            
            max_lambda_val = np.max(np.abs(eigenvalues))
            
            # Eğer 4.0000 çıkıyorsa rezonans kilidindedir, bunları 'Trivial' olarak işaretleyebiliriz.
            is_resonant = np.isclose(max_lambda_val, 4.0, atol=1e-4)
            
            return {
                "shell": shell_size,
                "mod": modular_class,
                "max_lambda": max_lambda_val,
                "type": "RESONANT (Locked)" if is_resonant else "DYNAMIC (Valid)"
            }
        except:
            return None

    def start_brute_force_loop(self):
        while True:
            print("-" * 65)
            user_input = input("[INPUT] Taranacak maksimum Kabuk Boyutunu (S) girin (örn: 20) veya 'exit': ").strip().lower()
            
            if user_input == 'exit':
                print("[AQF SYSTEM] Tarayıcı kapatıldı.")
                break
                
            if user_input.isdigit():
                max_s = int(user_input)
                print(f"\n{'Shell (S)':<10} | {'Mod Sınıfı':<10} | {'Max |λ|':<12} | {'Durum / Spektrum Tipi'}")
                print("-" * 65)
                
                # En baştan (S=3) başlayıp sırayla her şeyi deniyoruz
                for s in range(3, max_s + 1):
                    for m in [2, 3, 4, 6, 8]:
                        res = self.execute_single_test(shell_size=s, modular_class=m)
                        if res:
                            # Sadece kilitlenmemiş, gerçek veri üreten dinamik yapıları daha rahat görmek için 
                            # çıktıyı biçimlendiriyoruz.
                            print(f"{res['shell']:<10} | mod{res['mod']:<6} | {res['max_lambda']:.4f}     | {res['type']}")
                print("\n[AQF SYSTEM] Belirtilen aralıktaki tüm matris spektrumları tarandı. Yeni test bekleniyor.")
            else:
                print("[UYARI] Geçerli bir sayı girin.")

if __name__ == "__main__":
    scanner = AQFSequentialScanner()
    scanner.start_brute_force_loop()